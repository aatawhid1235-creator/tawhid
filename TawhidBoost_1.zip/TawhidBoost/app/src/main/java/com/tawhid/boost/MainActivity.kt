package com.tawhid.boost

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

private val Neon = Color(0xFFB388FF)
private val Cyan = Color(0xFF00E5FF)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon, background = Color.Black, surface = Color(0xFF101018))) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { Screen(tick) }
            }
        }
    }
}

data class Game(val label: String, val pkg: String)

fun loadGames(c: Context): List<Game> {
    val pm = c.packageManager
    return pm.getInstalledApplications(0).filter { it.category == ApplicationInfo.CATEGORY_GAME }
        .map { Game(pm.getApplicationLabel(it).toString(), it.packageName) }.sortedBy { it.label }
}

private fun refreshRates(c: Context): List<Int> =
    (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(0)
        .supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) = OutlinedCard(
    Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Neon),
    colors = CardDefaults.outlinedCardColors(containerColor = Color(0xFF101018))
) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }

@Composable
private fun Chips(opts: List<String>, sel: String, onPick: (String) -> Unit) =
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        opts.forEach { FilterChip(selected = it == sel, onClick = { onPick(it) }, label = { Text(it) }) }
    }

@Composable
private fun Screen(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Cfg.p(ctx) }
    var ready by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<Game?>(null) }
    var fps by remember { mutableStateOf(prefs.getString("fps", "60")!!) }
    var mode by remember { mutableStateOf(prefs.getString("mode", "PERFORMANCE")!!) }
    var overlay by remember { mutableStateOf(prefs.getBoolean("overlay", true)) }
    var boost by remember { mutableStateOf(prefs.getBoolean("boost", false)) }
    val games = remember { loadGames(ctx) }
    val rates = remember { refreshRates(ctx) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun check() { ready = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false } }
    LaunchedEffect(tick) { check(); boost = prefs.getBoolean("boost", false) }
    DisposableEffect(Unit) {
        val l = Shizuku.OnRequestPermissionResultListener { _, _ -> check() }
        try { Shizuku.addRequestPermissionResultListener(l) } catch (_: Throwable) {}
        onDispose { try { Shizuku.removeRequestPermissionResultListener(l) } catch (_: Throwable) {} }
    }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()
    fun sh(cmds: List<String>) = scope.launch {
        log = withContext(Dispatchers.IO) {
            try { cmds.joinToString("\n") { Sh.run(it) }.ifBlank { "Done (no output)" } } catch (e: Throwable) { "Failed: ${e.message}" }
        }
    }
    fun setBoost(on: Boolean) {
        val svc = Intent(ctx, BoostService::class.java)
        if (!on) { ctx.stopService(svc); prefs.edit().putBoolean("boost", false).apply(); boost = false; return }
        if (!ready) { toast("Start Shizuku and grant access first."); return }
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS); return
        }
        if (overlay && !Settings.canDrawOverlays(ctx)) {
            toast("Allow 'Display over other apps', then switch Boost on again.")
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            return
        }
        ContextCompat.startForegroundService(ctx, svc)
        prefs.edit().putBoolean("boost", true).apply(); boost = true
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("TAWHID BOOST", style = MaterialTheme.typography.headlineMedium, color = Neon) }
        item { Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (boost) "🟢 BOOST ACTIVE" else "⚪ BOOST OFF", Modifier.weight(1f), color = if (boost) Cyan else Color.Gray)
                Switch(checked = boost, onCheckedChange = { setBoost(it) })
            }
            Text(if (ready) "Shizuku: connected" else "Shizuku: not ready", style = MaterialTheme.typography.bodySmall)
            if (!ready) Button(onClick = { try { Shizuku.requestPermission(0) } catch (_: Throwable) { toast("Shizuku is not running.") } }) { Text("GRANT ACCESS") }
            Text("Refresh rates: ${rates.joinToString(", ") { "${it}Hz" }}" + if (rates.max() < 120) " • 120Hz not supported" else "", style = MaterialTheme.typography.bodySmall)
        } }
        item { Card {
            Text("SETTINGS", color = Cyan)
            Text("Performance mode"); Chips(listOf("BALANCED", "PERFORMANCE", "MAX"), mode) { mode = it; prefs.edit().putString("mode", it).apply() }
            Text("Target FPS"); Chips(listOf("30", "40", "60", "90", "120").filter { it.toInt() <= rates.max() }, fps) { fps = it; prefs.edit().putString("fps", it).apply() }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("FPS OVERLAY", Modifier.weight(1f))
                Switch(checked = overlay, onCheckedChange = { overlay = it; prefs.edit().putBoolean("overlay", it).apply() })
            }
            Text("Changes apply the next time a game starts.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        } }
        item { Card {
            Text("MANUAL BOOST: ${sel?.label ?: "tap a game below"}", color = Cyan)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = ready && sel != null, onClick = { sh(Cfg.applyCmds(mode, fps, sel!!.pkg)) }) { Text("BOOST") }
                OutlinedButton(enabled = ready && sel != null, onClick = { sh(Cfg.resetCmds(sel!!.pkg)) }) { Text("RESET") }
            }
            if (log.isNotBlank()) Text(log, style = MaterialTheme.typography.bodySmall)
        } }
        item { Text("MY GAMES (${games.size})", color = Neon) }
        items(games) { g -> Card {
            Text("🎮 ${g.label}", Modifier.clickable { sel = g })
            Text(g.pkg, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        } }
    }
}

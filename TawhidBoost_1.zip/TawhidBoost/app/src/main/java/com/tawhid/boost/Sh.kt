package com.tawhid.boost

import rikka.shizuku.Shizuku

/** Runs a shell command with Shizuku (ADB-level) privileges. newProcess is non-public in API 13, hence reflection. */
object Sh {
    fun run(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }
}

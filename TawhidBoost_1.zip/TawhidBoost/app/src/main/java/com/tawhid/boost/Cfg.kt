package com.tawhid.boost

import android.content.Context

object Cfg {
    fun p(c: Context) = c.getSharedPreferences("p", 0)
    fun applyCmds(mode: String, fps: String, pkg: String): List<String> {
        val (gm, scale) = when (mode) {
            "BALANCED" -> "standard" to "1.0"
            "PERFORMANCE" -> "performance" to "0.8"
            else -> "performance" to "0.6"
        }
        val n = if (gm == "performance") 2 else 1
        return listOf("cmd game mode $gm $pkg", "cmd game set --mode $n --downscale $scale --fps $fps $pkg")
    }
    fun resetCmds(pkg: String) = listOf("cmd game reset $pkg")
}

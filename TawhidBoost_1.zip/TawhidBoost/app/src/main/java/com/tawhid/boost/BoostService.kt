package com.tawhid.boost

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlin.math.roundToInt

class BoostService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ui = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var tv: TextView? = null
    private var cur: String? = null
    private lateinit var wm: WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { Cfg.p(this).edit().putBoolean("boost", false).apply(); stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        notify("Gaming Boost is active", true)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private fun notify(text: String, first: Boolean = false) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("boost", "Gaming Boost", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(this, 1, Intent(this, BoostService::class.java).setAction("STOP"), flags)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flags)
        val n = NotificationCompat.Builder(this, "boost").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("TAWHID BOOST").setContentText(text).setOngoing(true)
            .addAction(0, "STOP BOOST", stop).addAction(0, "OPEN APP", open).build()
        if (first) ServiceCompat.startForeground(this, 1, n, if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        else nm.notify(1, n)
    }

    private suspend fun loop() {
        val games = loadGames(this).map { it.pkg }.toSet()
        var layer: String? = null
        while (currentCoroutineContext().isActive) {
            val top = try { Sh.run("dumpsys activity activities | grep -m1 topResumedActivity") } catch (_: Throwable) { "" }
            val pkg = Regex("([a-zA-Z0-9_.]+)/").find(top)?.groupValues?.get(1)
            val g = if (pkg in games) pkg else null
            if (g != cur) {
                cur?.let { runCmds(Cfg.resetCmds(it)) }
                cur = g; layer = null
                if (g == null) { hideOverlay(); notify("Gaming Boost is active") }
                else {
                    val p = Cfg.p(this@BoostService)
                    runCmds(Cfg.applyCmds(p.getString("mode", "PERFORMANCE")!!, p.getString("fps", "60")!!, g))
                    notify("GAME BOOST ACTIVE: $g")
                    if (p.getBoolean("overlay", true) && Settings.canDrawOverlays(this@BoostService)) showOverlay()
                }
            }
            if (g != null) {
                layer = layer ?: findLayer(g)
                val f = layer?.let { try { fps(it) } catch (_: Throwable) { null } }
                setText(stats(f))
                delay(1000)
            } else delay(3000)
        }
    }

    private fun runCmds(c: List<String>) = c.forEach { try { Sh.run(it) } catch (_: Throwable) {} }

    private fun findLayer(pkg: String): String? = try {
        val l = Sh.run("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { pkg in it }
        l.firstOrNull { "SurfaceView" in it } ?: l.firstOrNull { "Background" !in it && "Bounds" !in it }
    } catch (_: Throwable) { null }

    private fun fps(layer: String): Int? {
        val t = Sh.run("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
            .mapNotNull { it.split("\t").getOrNull(1)?.trim()?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }
        if (t.size < 2) return null
        val span = (t.max() - t.min()) / 1e9
        return if (span > 0) ((t.size - 1) / span).roundToInt() else null
    }

    private fun stats(f: Int?): String {
        val mi = ActivityManager.MemoryInfo().also { getSystemService(ActivityManager::class.java).getMemoryInfo(it) }
        val gb = 1024.0 * 1024 * 1024
        val hz = (getSystemService(DisplayManager::class.java).getDisplay(0).refreshRate).roundToInt()
        val temp = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra("temperature", -1) ?: -1
        return "${if (f != null) "FPS: $f" else "FPS unavailable"}\nRefresh: ${hz}Hz\n" +
            "RAM: %.1f / %.1f GB\nCPU: --%%\nTEMP: ${if (temp > 0) "${temp / 10}°C" else "--"}".format((mi.totalMem - mi.availMem) / gb, mi.totalMem / gb)
    }

    private fun setText(s: String) { ui.post { tv?.text = s } }

    private fun showOverlay() = ui.post {
        if (tv != null) return@post
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 120 }
        val v = TextView(this).apply {
            setTextColor(Color.parseColor("#00E5FF")); textSize = 11f; typeface = Typeface.MONOSPACE
            setBackgroundColor(Color.argb(110, 0, 0, 0)); setPadding(16, 8, 16, 8); text = "…"
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, lp) }
            }
            true
        }
        try { wm.addView(v, lp); tv = v } catch (_: Throwable) {}
    }

    private fun hideOverlay() = ui.post { tv?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; tv = null }

    override fun onDestroy() {
        job?.cancel()
        val g = cur
        hideOverlay()
        if (g != null) Thread { runCmds(Cfg.resetCmds(g)) }.start()
        scope.cancel()
        super.onDestroy()
    }
}
